# Runbook

## Session Workflow (Codex)
- Use `docs/commands/open-session.md` to start every session.
- Use `docs/commands/close-session.md` to end every session.
- Update docs during implementation, not only at the end.
- Documentation must be English-only (no Cyrillic).

## Local Development
TODO: steps to start local services, env vars, and health checks.

## Dependencies
- Install (pip): `python -m pip install -r requirements.txt`
- Install (uv): `uv sync`

## Migrations
- Create: `python scripts/migrate.py create <name>`
- Apply: `python scripts/migrate.py apply`
- Rollback: `python scripts/migrate.py rollback`
- Status: `python scripts/migrate.py status`

## Backup & Restore (SQLite)
### Backup (manual, Windows PowerShell)
1. Create a backup (direct helper):
   `$env:PYTHONPATH="src"; python scripts/db_backup_job.py --run`
2. Create a backup (scheduler job):
   `$env:PYTHONPATH="src"; python scripts/db_backup_job.py --job db_backup_weekly`

Output includes:
- `backup_path=...`
- `snapshot_path=...` (if enabled)
- `integrity_check=ok` (if check ran)

### Backup Configuration (env)
- `BACKUP_DIR` (default: `./data/backups`)
- `BACKUP_PREFIX` (default: `db_backup`)
- `BACKUP_RETENTION` (default: `6`)
- `BACKUP_SNAPSHOT_ENABLED` (default: `true`)
- `BACKUP_SNAPSHOT_PATHS` (default: `["docs"]`)

### Rotation Policy
- Rotation keeps the newest `BACKUP_RETENTION` DB backups.
- When a DB backup is rotated out, its paired snapshot ZIP (same timestamp) is removed as well.

### Restore Verification (manual, Windows PowerShell)
1. Stop the bot/sidecar process.
2. Copy the backup file to a restore target:
   `Copy-Item .\data\backups\db_backup_YYYYMMDD_HHMMSSZ.sqlite .\data\app_restored.db`
3. Run integrity check on the restored DB:
   `$env:PYTHONPATH="src"; python - <<'PY'\nimport sqlite3\nwith sqlite3.connect(\"data/app_restored.db\") as conn:\n    row = conn.execute(\"PRAGMA integrity_check;\").fetchone()\n    print(row[0])\nPY`
   Expected output: `ok`
4. Optional sanity query:
   `$env:PYTHONPATH="src"; python - <<'PY'\nimport sqlite3\nwith sqlite3.connect(\"data/app_restored.db\") as conn:\n    print(conn.execute(\"SELECT COUNT(*) FROM artifacts;\").fetchone()[0])\nPY`
5. If you want to restore in place:
   - Stop all processes using the DB.
   - Replace `data/app.db` with `data/app_restored.db`.

### Scheduling (Windows Task Scheduler)
- Program/script: `python`
- Arguments:
  `scripts/db_backup_job.py --run`
- Start in: `D:\openclaw_bot\agent-second-brain`

## Verification
- Scheduler smoke test (no-op): run a short script or REPL and call
  `Scheduler(build_default_registry()).run_once("noop")`.
- Reminders trigger smoke test (no-op DB state):
  `Scheduler(build_default_registry()).run_once("reminder_tick")`.
- Stage 3 plans/reminders smoke test (local):
  0. Apply migrations (PowerShell):
     `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
  1. Apply migrations (bash):
     `PYTHONPATH=src python scripts/migrate.py apply`
  2. Run Stage 3 smoke (PowerShell):
     `$env:PYTHONPATH="src"; python scripts/plan_reminder_smoke.py`
  3. Run Stage 3 smoke (bash):
     `PYTHONPATH=src python scripts/plan_reminder_smoke.py`
  3a. Run Stage 3 parse-only smoke (PowerShell):
     `$env:PYTHONPATH="src"; $env:STAGE3_SMOKE_MODE="parse"; python scripts/plan_reminder_smoke.py`
  3b. Run Stage 3 parse-only smoke (bash):
     `PYTHONPATH=src STAGE3_SMOKE_MODE=parse python scripts/plan_reminder_smoke.py`
  3c. Expected output (parse-only):
     `stage3_parse_smoke_ok`
     `parsed_title=Stage 3 parse smoke`
     `parsed_start_at=2026-02-23T23:00:00+00:00`
     `parsed_remind_at=2026-02-23T23:00:00+00:00`
     `parsed_event_id=1`
     `parsed_reminder_id=1`
     `parse_logs=1`
  4. Verify rows (PowerShell):
     `$env:PYTHONPATH="src"; python - <<'PY'\nimport sqlite3\nfrom d_brain.config import get_settings\ns = get_settings()\nwith sqlite3.connect(s.db_path) as c:\n    events = c.execute(\"SELECT COUNT(*) FROM events;\").fetchone()[0]\n    reminders = c.execute(\"SELECT COUNT(*) FROM event_reminders;\").fetchone()[0]\n    logs = c.execute(\"SELECT COUNT(*) FROM event_parse_logs;\").fetchone()[0]\n    print(f\"events={events}\")\n    print(f\"event_reminders={reminders}\")\n    print(f\"event_parse_logs={logs}\")\nPY`
  5. Verify rows (bash):
     `PYTHONPATH=src python - <<'PY'\nimport sqlite3\nfrom d_brain.config import get_settings\ns = get_settings()\nwith sqlite3.connect(s.db_path) as c:\n    events = c.execute(\"SELECT COUNT(*) FROM events;\").fetchone()[0]\n    reminders = c.execute(\"SELECT COUNT(*) FROM event_reminders;\").fetchone()[0]\n    logs = c.execute(\"SELECT COUNT(*) FROM event_parse_logs;\").fetchone()[0]\n    print(f\"events={events}\")\n    print(f\"event_reminders={reminders}\")\n    print(f\"event_parse_logs={logs}\")\nPY`
- Stage 2 ingestion smoke test (local):
  Note: `ModuleNotFoundError` happens with a `src/` layout when `d_brain` is not on
  `PYTHONPATH` or installed in the environment. Use the commands below or run
  the script which adds `src/` to `sys.path`.
  Minimal env vars for Stage 2 smoke tests:
  - `DB_PATH` (optional, defaults to `./data/app.db`)
  - `MIGRATIONS_PATH` (optional, defaults to `./deploy/migrations`)
  - `DEEPGRAM_API_KEY` is not required unless voice/STT features are used.
  0. Install dependencies:
     - `python -m pip install -r requirements.txt`
     - `uv sync`
  1. Apply migrations (PowerShell):
     `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
  2. Apply migrations (bash):
     `PYTHONPATH=src python scripts/migrate.py apply`
  3. Run ingest smoke (PowerShell):
     `$env:PYTHONPATH="src"; python scripts/ingest_smoke.py`
  4. Run ingest smoke (bash):
     `PYTHONPATH=src python scripts/ingest_smoke.py`
  5. Verify rows (PowerShell):
     `$env:PYTHONPATH="src"; python - <<'PY'\nimport sqlite3\nfrom d_brain.config import get_settings\ns = get_settings()\nwith sqlite3.connect(s.db_path) as c:\n    a = c.execute(\"SELECT COUNT(*) FROM artifacts;\").fetchone()[0]\n    b = c.execute(\"SELECT COUNT(*) FROM artifact_summaries;\").fetchone()[0]\n    print(f\"artifacts={a}\")\n    print(f\"artifact_summaries={b}\")\nPY`
  6. Verify rows (bash):
     `PYTHONPATH=src python - <<'PY'\nimport sqlite3\nfrom d_brain.config import get_settings\ns = get_settings()\nwith sqlite3.connect(s.db_path) as c:\n    a = c.execute(\"SELECT COUNT(*) FROM artifacts;\").fetchone()[0]\n    b = c.execute(\"SELECT COUNT(*) FROM artifact_summaries;\").fetchone()[0]\n    print(f\"artifacts={a}\")\n    print(f\"artifact_summaries={b}\")\nPY`
  7. Verify rows (alt, no PYTHONPATH):
     ```bash
     python - <<'PY'
     import sqlite3
     import sys
     from pathlib import Path
     root = Path(".").resolve()
     src = root / "src"
     if src.exists() and str(src) not in sys.path:
         sys.path.insert(0, str(src))
     from d_brain.config import get_settings
     s = get_settings()
     with sqlite3.connect(s.db_path) as c:
         a = c.execute("SELECT COUNT(*) FROM artifacts;").fetchone()[0]
         b = c.execute("SELECT COUNT(*) FROM artifact_summaries;").fetchone()[0]
         print(f"artifacts={a}")
         print(f"artifact_summaries={b}")
     PY
     ```
- Stage 4 English MVP smoke test (local):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Apply migrations (bash):
      `PYTHONPATH=src python scripts/migrate.py apply`
   2. Run Stage 4 smoke (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/english_mvp_smoke.py`
   3. Run Stage 4 smoke (bash):
      `PYTHONPATH=src python scripts/english_mvp_smoke.py`
 - Stage 5 Reflection MVP smoke test (local):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Apply migrations (bash):
      `PYTHONPATH=src python scripts/migrate.py apply`
   2. Run Stage 5 smoke (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/reflection_smoke.py`
   3. Run Stage 5 smoke (bash):
      `PYTHONPATH=src python scripts/reflection_smoke.py`
 - Stage 6 News MVP smoke test (local):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Apply migrations (bash):
      `PYTHONPATH=src python scripts/migrate.py apply`
   2. Run Stage 6 smoke (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/news_mvp_smoke.py`
   3. Run Stage 6 smoke (bash):
      `PYTHONPATH=src python scripts/news_mvp_smoke.py`
 - Stage 6 News Briefing smoke test (local):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Apply migrations (bash):
      `PYTHONPATH=src python scripts/migrate.py apply`
   2. Run Stage 6 briefing smoke (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/news_briefing_smoke.py`
   3. Run Stage 6 briefing smoke (bash):
      `PYTHONPATH=src python scripts/news_briefing_smoke.py`
 - Stage 7 Digest + Heartbeat smoke test (local):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Apply migrations (bash):
      `PYTHONPATH=src python scripts/migrate.py apply`
   2. Run Stage 7 smoke (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/digest_smoke.py`
   3. Run Stage 7 smoke (bash):
      `PYTHONPATH=src python scripts/digest_smoke.py`
 - Stage 8 Codex limits smoke test (local):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Apply migrations (bash):
      `PYTHONPATH=src python scripts/migrate.py apply`
   2. Run Stage 8 smoke (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/codex_limits_smoke.py`
   3. Run Stage 8 smoke (bash):
      `PYTHONPATH=src python scripts/codex_limits_smoke.py`
 - Stage 9 Health MVP smoke test (local):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Apply migrations (bash):
      `PYTHONPATH=src python scripts/migrate.py apply`
   2. Run Stage 9 smoke (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/health_mvp_smoke.py`
   3. Run Stage 9 smoke (bash):
      `PYTHONPATH=src python scripts/health_mvp_smoke.py`
- Stage 10 Idea Research smoke test (local):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Apply migrations (bash):
      `PYTHONPATH=src python scripts/migrate.py apply`
   2. Run Stage 10 smoke (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/idea_research_smoke.py`
   3. Run Stage 10 smoke (bash):
      `PYTHONPATH=src python scripts/idea_research_smoke.py`
- Stage 11 Telegram UX wiring checklist (manual):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Start the bot (same as current run flow).
   2. Plans/reminders:
      `/plan add Test plan`
      `/plan list`
      `/reminder list`
   3. Notes/ingest:
      `/note This is a test note`
      `/note https://example.com`
   4. English:
      `/word add hello`
      `/word list`
      `/topic add Travel`
      `/topic list`
   5. News:
      `/news latest` (expect "No records found." if empty)
   6. Health:
      `/health add Headache`
      `/health list`
   7. Reflection:
      `/reflect start` (capture session id)
      `/reflect add <session_id> Feeling focused today`
      `/reflect close <session_id>`
   8. Digest:
      `/digest latest` (expect "No records found." if empty)
   9. Codex usage:
      `/usage`

- Stage 12 Voice English Tutor MVP checklist (manual):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Start the bot (same as current run flow).
   2. Start tutor session:
      `/tutor start 15`
   3. Send a short text message and verify a reply is returned.
   4. Send a voice message and verify:
      - STT produces a transcript (or a clear STT error if not configured).
      - Both user and assistant turns are stored in `english_session_turns`.
      - If TTS is configured, a voice reply is returned; otherwise text fallback is returned.
   5. Check tutor status:
      `/tutor status`
   6. Stop tutor session:
      `/tutor stop`

- Stage 13 Reflection Voice Loop MVP checklist (manual):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Start the bot (same as current run flow).
   2. Start reflection session:
      `/reflect start`
   3. Send a short text message and verify a reply is returned.
   4. Send a voice message and verify:
      - STT produces a transcript (or a clear STT error if not configured).
      - Both user and assistant turns are stored in `reflection_turns`.
      - If TTS is configured, a voice reply is returned; otherwise text fallback is returned.
   5. Close reflection session:
      `/reflect close <session_id> [summary]`

- Stage 14 Books / Philosophy / Knowledge UX MVP checklist (manual):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Start the bot (same as current run flow).
   2. Books:
      `/book add Deep Work by Cal Newport`
      `/book list`
   3. Philosophy:
      `/philosophy add https://example.com/stoicism`
      `/philosophy list`
   4. Knowledge inbox:
      `/inbox add https://example.com/interesting.pdf`
      `/inbox list`
   5. Summarize:
      `/inbox summarize <artifact_id>`
   6. Save:
      `/inbox save <artifact_id> [Optional title]`
   7. Verify persistence in SQLite:
      - `artifacts`, `artifact_summaries`, `notes`, `note_categories`

- Stage 15 News Automation + Morning Briefing Delivery MVP checklist (manual):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   0a. Dependency note:
      - Telegram delivery uses `httpx`. Install with `python -m pip install httpx` if missing.
   1. Generate a briefing (Telegram):
      `/news generate`
   2. Deliver latest briefing (Telegram):
      `/news deliver`
   3. Validate message formatting:
      - header shows "Morning Briefing"
      - exactly 5 items
      - each item includes a source link when available
   4. Scheduler job sanity (local):
      `PYTHONPATH=src python scripts/news_briefing_job.py --all`
   5. Verify delivery traceability:
      - Check `heartbeat_logs` for `event_type=news_delivery`

- Stage 16 Reminders Delivery + Calendar Views MVP checklist (manual):
   0. Apply migrations (PowerShell):
      `$env:PYTHONPATH="src"; python scripts/migrate.py apply`
   1. Create a plan/reminder:
      `/plan add Test reminder`
   2. Force due reminder (update remind_at to now or past via DB or use rule-based input).
   3. Manual delivery trigger:
      `/reminder deliver`
   4. Verify Telegram receives reminder message.
   5. Calendar views:
      `/calendar today`
      `/calendar upcoming 5`
      `/calendar date 2026-02-23`
   6. Verify delivery traceability:
      - Check `heartbeat_logs` for `event_type=reminder_delivery` with `reminder_id` and `event_id`.

## Debugging
TODO: logs, tracing, and common failure modes.
